package com.github.lwphk.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.lwphk.demo.dao.entity.User;
import com.github.lwphk.demo.dao.entity.UserExample;
import com.github.lwphk.demo.dao.mapper.UserMapper;
import com.github.lwphk.pagehelper.common.Page;

@RestController
public class PageController {

	
	@Autowired
	UserMapper mapper;
	
	@RequestMapping("/list")
	public Page<User> index(@RequestParam(defaultValue="1")Integer pageNo,@RequestParam(defaultValue="5")Integer pageSize) {
		Page<User> page = new Page<>(pageNo, pageSize);
		UserExample example = new UserExample();
		example.setDistinct(true);
		example.setOrderByClause("id desc");
		example.createCriteria().andIdGreaterThanOrEqualTo(1);
		page.setResult(mapper.selectByExample(example, page));
		return page;
	}
}
